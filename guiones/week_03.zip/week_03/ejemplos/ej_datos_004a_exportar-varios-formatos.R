#- vamos a ver como podríamos exportar iris a 3 formatos diferentes usando un bucle for
library(tidyverse)


#- estructura de un bucle for
for (ii in 1:3) {
  print(ii)
}

#- 0) Vamos a usar la f. rio::export() ; algo como:
# rio::export(iris, here::here("pruebas", "iris.csv"))

#- 1) creamos un vector con los nombres de los 3 archivos
my_vec <- c("iris.csv", "iris.xlsx", "iris.sav")

#- 2) generamos las rutas de los archivos
my_rutas <- paste0("./pruebas/", my_vec)

my_rutas <- paste0(here::here("pruebas"), "/", my_vec)

#- 3) bucle para guardar

#- antes borramos todos los archivos de "./pruebas/"
fs::dir_delete("pruebas")
#- volvemos a crear la carpeta
fs::dir_create("pruebas")

for (ii in 1:3) {
  print(my_rutas[ii])
  rio::export(iris, my_rutas[ii])
}


#- 4) con purrr y lapply
purrr::map(my_rutas, .f = \(xx) rio::export(iris, file = xx))
lapply(my_rutas, FUN = \(xx) rio::export(iris, file = xx))




#- vamos a importar todos los ficheros q hay ahora en "pruebas" ----------------

#- cojo las rutas a los archivos
my_carpeta <- here::here("pruebas") #- la carpeta donde están los archivos q quiero importar
mys_rutas <- list.files(my_carpeta)   #- Ok con base ...
mys_rutas <- fs::dir_ls(my_carpeta)  #- pero mejor con el pkg "fs"
mys_rutas



#- con purrr es easy, PERO hay que saber un poco sobre manipular listas
my_dfs_list <- purrr::map(mys_rutas, rio::import)
