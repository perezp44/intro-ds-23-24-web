# Hacer soniditos con R: https://github.com/brooke-watson/BRRR
#- Atención!!, no tenéis el pkg instalado

library(BRRR)    #- remotes::install_github("brooke-watson/BRRR")


#- hacemps sonar el sonid 30, llamado "jayz1"
BRRR::skrrrahh(30)
BRRR::skrrrahh(sound = 30)
BRRR::skrrrahh(sound = "jayz1")

BRRR::skrrrahh(30)


#- vemos los sonidos q tiene el pkg
BRRR::skrrrahh_list()

aa <- as.data.frame(BRRR::skrrrahh_list())  # para verlos mejor


#- hacemos sonar los 4 primeros sonidos (!!)
for(ii in 1:4) {
  BRRR::skrrrahh(sound = ii)
  Sys.sleep(1)   #- 
}



#- creamos una función (!!!!!!) ------------------------------------------------
my_fun <- function(sound, sleep = 0.2) {
  BRRR::skrrrahh(sound)
  my_sonido <- sample(1:52, 1) #- elegimos un numero (sonido) al azar
  Sys.sleep(sleep)
  BRRR::skrrrahh(sound = my_sonido)
  Sys.sleep(sleep)
}

## WARNING: THIS WILL MAKE SOUND!!!!
for(ii in 1:3) {
  my_fun(sound = 30, ii)
}


#- R tiene paquetes para hacer música y tablaturas ... PERO hay q instalar cosas
#- por ejemplo el paquete gm: https://flujoo.github.io/gm/

