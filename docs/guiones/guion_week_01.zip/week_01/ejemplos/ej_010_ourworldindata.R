#- https://ourworldindata.org/        #- es una publicación de Oxford que provee algunos conjuntos de datos
#- https://github.com/piersyork/owidR      #- paquete de R q facilita el uso de esos datos

#- instalamos el paquete
#devtools::install_github("piersyork/owidR")
library(owidR)
owidR::owid_search("poverty")
#- buscamos datos sobre derechos humanos
owidR::owid_search("human rights")

#- descargamos los datos sobre humam rights scores
rights <- owidR::owid("human-rights-scores")
owidR::owid_source(rights) #- da informacion sobre esos datos

owid_plot(rights, summarise = FALSE, filter = c("North Korea", "Afghanistan", "France", "Spain", "United States"))


#- TAREA: visualiza 
my_term <- "human-rights-violations"
df <- owidR::owid(my_term)
owidR::owid_source(df)
owid_plot(df)

owid_plot(df, summarise = FALSE, filter = c("North Korea", "Afghanistan", "France", "Spain", "United States"))

