#- para replicar esto de Tierney: https://www.njtierney.com/post/2020/06/01/tidy-anscombe/
#- anscombiser, un pkg q hace datos con mismos estadísticos: https://cran.r-project.org/web/packages/anscombiser/vignettes/intro-to-anscombiser.html

library(tidyverse)

#- https://es.wikipedia.org/wiki/Cuarteto_de_Anscombe
#- el df anscombe tiene 4 conjuntos de datos q tienen las mismas propiedades estadisticas pero su gráfico es muy diferente
class(anscombe)     #- es un df
summary(anscombe)    #- tienen las mismas propiedades estadísticas: media, mediana ....
print(as_tibble(anscombe))  #- perp los datos son diferentes

#- vamos a gráficarlos todos a la vez
tidy_anscombe <- anscombe %>%
  pivot_longer(cols = everything(),
               names_to = c(".value", "set"),
               names_pattern = "(.)(.)")

#- tienen un gráfico muy diferente
ggplot(tidy_anscombe, aes(x = x, y = y)) + 
  geom_point() + 
  facet_wrap(~set)

#- !!!!!! ----------------------------------------------------------------------

#- volvamos a ver el summary de los 4 conjuntos de datos
tidy_anscombe_summary <- tidy_anscombe %>% group_by(set) %>%
          summarise(across(.cols = everything(),
                      .fns = lst(min,max,median,mean,sd,var),
                      .names = "{col}_{fn}"))


#- estimamos un MRL para cada uno de los 4 conjuntos de datos
#- map(data)  es xq nest llama "data" a la columna con los datos
library(broom)

tidy_anscombe_models <- tidy_anscombe %>% group_nest(set) %>% 
      mutate(fit = map(data, ~lm(y ~ x, data = .x)),
             tidy = map(fit, tidy),
             glance = map(fit, glance))


#- unnest los coeficientes
tidy_anscombe_models %>% unnest(cols = c(tidy)) 


#- But we’ll need to make the dataset wider with pivot_wider:
tidy_anscombe_models %>% 
  unnest(cols = c(tidy)) %>% 
  pivot_wider(id_cols = c(set,term),
              names_from = term,
              values_from = estimate)
#- R2 lo hará bien
tidy_anscombe_models %>% 
  unnest(cols = c(glance)) %>% 
  select(set, r.squared:df.residual)


library(ggplot2)
ggplot(tidy_anscombe, aes(x = x, y = y)) +
  geom_point() + 
  facet_wrap(~set) +
  geom_smooth(method = "lm", se = FALSE)
