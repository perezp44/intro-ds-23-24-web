#- density plots----------------------
library(ggplot2)
iris <- iris

#- grafico con f. de densidad estimada geom_density()
ggplot(iris, aes(x = Sepal.Length)) + geom_density()

ggplot(iris, aes(x = Sepal.Length)) + geom_density(aes(group = Species))
ggplot(iris, aes(x = Sepal.Length)) + geom_density(aes(color = Species))

ggplot(iris, aes(x = Sepal.Length)) + geom_density() + facet_grid(. ~ Species)
ggplot(iris, aes(x = Sepal.Length)) + geom_density(aes(color = Species)) + facet_grid(. ~ Species)


ggplot(iris, aes(x = Sepal.Length)) + 
  geom_density(aes(group = Species, colour = Species, fill = Species), alpha = 0.3)



#- Joy Division plot con el pkg ggridges
library(ggridges)
ggplot(iris, aes(x = Sepal.Length, y = Species)) + geom_density_ridges()


ggplot(iris, aes(x = Sepal.Length, y = Species)) + geom_density_ridges(aes(fill = Species))



#- boxplots 
ggplot(data = iris) +
  geom_boxplot(mapping = aes(x = reorder(Species, Sepal.Length, FUN = mean), y = Sepal.Length))


#- boxplot, ahora con mtcars
ggplot(data = mpg) +
  geom_boxplot(mapping = aes(x = reorder(class, hwy, FUN = median), y = hwy))

#- violin plots ----
# instalar lvplot pkg  geom_lv()   devtools::install_github("lvplot/hadley")
p <- ggplot(data = mpg) +
  geom_violin(mapping = aes(x = hwy, y = reorder(class, hwy, FUN = median), )) 
p

# para hacer zoom
p + coord_cartesian(xlim = c(20, 30))

