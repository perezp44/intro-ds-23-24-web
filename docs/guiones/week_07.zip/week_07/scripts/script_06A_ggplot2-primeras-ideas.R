#- script para seguir las slides de ggplot2
library(tidyverse)

#- slides_06A: primeras ideas --------------------------------------------------

#- slide nº 5 ----
ggplot(iris, 
       aes(x = Sepal.Length, 
           y = Petal.Length, 
           color = Species)) + 
  geom_point()

#- forma más compacta de escribirlo
ggplot(iris, aes(x = Sepal.Length, y = Petal.Length, color = Species)) + 
  geom_point()

#- slide nº 7 ----

#- Fíjate: sólo hay 2 variables en aes()
ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point()

#- Fíjate: ahora usamos geom_line()
ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_line() 

#- Fíjate: Ahora usamos 2 geom_xx
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() +  
  geom_smooth() 

#- Fíjate: volvemos a tener 3 variables asociadas a estéticas 
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point()

#- Fíjate**: hay argumentos dentro de geom_point() 
#- Uno de ellos es `color`
ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point(color = "red", size = 2, alpha = 0.2)



#- slide nº 9 ----

ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point()

ggplot(iris) + geom_point(aes(Sepal.Length, Petal.Length))

ggplot() + geom_point(data = iris, aes(Sepal.Length, Petal.Length))


#- slide nº 11 ----
#- ¿qué hacen estas 3 expresiones?

ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point() + geom_smooth()

ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point(aes(color = Species)) + geom_smooth()

ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point() + geom_smooth(aes(color = Species))

#- slide nº 12 ----
#- ejemplos: ¿por qué no funcionan 3 de estas 4 expresiones?

ggplot(iris) + geom_point(aes(Sepal.Length, Petal.Length)) + 
  geom_smooth(aes(color = Species))

ggplot() + geom_point(data = iris, aes(Sepal.Length, Petal.Length)) + 
  geom_line(aes(Sepal.Length, Petal.Length))


ggplot(aes(Sepal.Length, Petal.Length)) + geom_point(data = iris) + 
  geom_line()

ggplot() + geom_point(data = iris, aes(Sepal.Length, Petal.Length)) + 
  geom_line()


#- slide nº 13 ----
#- un ejemplo un poco marciano

iris2 <- iris %>% filter(Species != "setosa") #- lirios que no son "setosa"

ggplot() + 
  geom_point(data = iris, aes(Sepal.Length, Petal.Length, color = Species)) +
  geom_smooth(data = iris2, aes(Sepal.Length, Petal.Length)) 

ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point(aes(color = Species)) + geom_smooth(data = iris2)



#- slide nº 14 ----
#- TAREA: Quiero que las 2 especies de lirios grandes se representen con el mismo color, ¿cómo lo hago?

#- solución 1
iris_setosa <- iris %>% filter(Species == "setosa") #- me quedo con los lirios pequeños, los de clase "setosa"

ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + 
  geom_point(data = iris_setosa, aes(color = Species)) + 
  geom_smooth(data = iris2, aes(Sepal.Length, Petal.Length) )

#- solución 2
iris_solo_2_clases <- iris %>% 
  mutate(Species_2 = ifelse(Species %in% c("versicolor", "virginica"), "versi_virgi", "setosa"))
ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point() + 
  geom_point(data = iris_setosa, aes(color = Species)) +
  geom_smooth(data = iris_solo_2_clases,aes(Sepal.Length, Petal.Length, color = Species_2) )

#- solución 3
iris_solo_2_clases <- iris %>% 
  mutate(Species_2 = ifelse(Species %in% c("versicolor", "virginica"), "versi_virgi", "setosa"))
ggplot(iris_solo_2_clases, aes(Sepal.Length, Petal.Length, color = Species_2)) + 
  geom_point() + geom_smooth()


#- slide nº 15 ----

ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point() + geom_smooth()
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point() + geom_smooth()
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point(color = "purple") + geom_smooth()
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point() + geom_smooth(color = "brown")
ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point() + geom_smooth(aes(color = Species))
ggplot(iris) + 
  geom_point(aes(Sepal.Length, Petal.Length, color = Species) ) +
  geom_smooth(aes(Sepal.Length, Petal.Length, color = Species))


#- slide nº 16 ----

#- Graph Gallery: https://exts.ggplot2.tidyverse.org/gallery/

#- Mapping ggplot geoms and aesthetic parameters : https://www.yihanwu.ca/post/geoms-and-aesthetic-parameters/




#- slides_06B: mas elementos ---------------------------------------------------


#- TITULOS -----------------------------

#- slide nº 5 ----

p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point()

p

#- slide nº 6 ----
p <- p +
  labs(title = "Gráfico 1: Longitud del sépalo frente al pétalo",
       subtitle = "(diferenciando por especie de lirio)",
       caption = "Datos provenientes del Iris dataset",
       x = "Longitud del sépalo",
       y = "Longitud del pétalo",
       color = "Especie de lirio",
       tag = "Plot 1")
p

p + theme(legend.position = "none")  #- quito leyenda


p <- ggplot(mtcars, aes(mpg, wt, colour = cyl)) + geom_point()



#- THEME -----------------------------

#- slide nº 7 ----

p + theme_gray()   #- tema por defecto
p + theme_light() 
p + theme_dark() 
p + theme_minimal() 
p + theme_void()


#- slide nº 8 ----

library(ggthemes)

p + theme_economist()
p + theme_wsj()
p + theme_fivethirtyeight() 
p + theme_gdocs()
p + theme_stata() 
p + theme_excel()


#- slide nº 9 ----
#- definiendo mi propio theme

my_theme <- theme(
  axis.text.x = element_text(colour = "grey20", size = 12, angle = 78, hjust = 0.5, vjust = 0.5) ,   
  axis.text.y = element_text(colour = "pink", size = 12) ,
  text = element_text(size = 46))

p + my_theme

#- podemos fijar el theme
theme_set(theme_minimal())  
p

# podemos fijar un theme y variar algún elemento (p.ej: eje X sin ticks ni escalas)
theme_set(theme_minimal() + theme(axis.text.x = element_blank()))
p

# si queremos volver al default theme
theme_set(theme_gray())
p


help(theme)

#- algunos ejemplos
p + theme(legend.position = "none")    #- que no aparezca leyenda
p + theme(legend.position = "bottom")  #- leyenda abajo
p + theme(legend.direction = "horizontal") #- leyenda horizontal!!
p + theme(legend.title = element_text(size = 22)) #- título de la leyenda a 22
p + theme(legend.key.size = unit(2.4, "cm"))   #- tamaño de los cuadros de la leyenda
p + theme(text = element_text(size = 20, face = "bold"))  #- cambiar tamaño de todos los elementos de texto
p + theme(text = element_text(face = "bold")) #- pone en negrita todos los elementos de texto
p + theme(axis.text.x = element_text(colour = "pink", size = 12, angle = 90, hjust = 0.5, vjust = 0.5)) # apariencia de la escala del eje x
p + theme(axis.title.y = element_text(size=25, angle = 45)) #- tamaño y angulo del texto del eje Y
p + theme(plot.subtitle = element_text(hjust = 3)) #- posición horizontal del subtitulo (si lo tuviese)
p + theme(plot.caption = element_text(hjust = 3)) #- posición vertical del pie de gráfico (si lo tuviese)
p + theme(panel.background = element_rect(fill = "green", colour = "pink", linetype = "longdash", size = 3.5))
p + theme(panel.background = element_blank())
p + theme(panel.background = NULL)
p + theme(plot.background = element_rect(fill = "pink", colour = "purple", linetype = "dotted", size = 7))


#- slide nº 10 ----
#- Elementos del theme un plot: https://henrywang.nl/ggplot2-theme-elements-demonstration/


#- slide nº 11 ----
#- colores 

aa <- as.data.frame(colours())
#- https://pkg.garrickadenbuie.com/r-colors-css/




#- SMALL MULTIPLES (Facetting) -------------------------------------------------


p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point()
p

#- slide nº 13 ----

p + facet_grid(cols = vars(Species))   # gráficos x columnas
p + facet_grid(rows = vars(Species))   # gráficos x filas
p + facet_wrap(vars(Species), nrow = 2, ncol = 2) # graf x filas y columnas


#- slide nº 14 ----
#- small multiples con 2 variables categóricas

iris_2 <- iris %>% mutate(Petal_2 = ntile(Petal.Width, 2))

iris_2  %>% ggplot() + 
  geom_point(aes(Sepal.Length, Petal.Length, color = Species)) +
  facet_grid(rows = vars(Petal_2), cols = vars(Species))


#- slide nº 15 ----

#- ejes de los small multiples (!!)
p + facet_grid(rows = vars(Species))    #- escalas comunes

p + facet_grid(rows = vars(Species), scales = "free")   #- las escalas de cada small pueden variar

p + facet_grid(rows = vars(Species), scales = "free_y") #- solo dejamos libre/variar la escala del eje y


#- ANOTACIONES
#- Annotations are a special type of layer that don’t inherit global settings from the plot. They are used to add fixed reference data to plots

#- slide nº 17 ----
#- anotaciones con annotate()

p + annotate(geom = "text", x = 6, y = 2, label = "Una anotación", size = 5)

p + annotate("rect", xmin = 6, xmax = 7,ymin = -Inf, ymax = Inf, alpha = 0.2, fill = "pink") 

p + annotate("segment", x = 5, xend = 7, y = 6, yend = 8, colour = "blue")


#- anotaciones con geom_text()

p + geom_text(aes(label = Petal.Length)) 

p + geom_text(aes(label = Species))

#- otro ejemplo mejor
iris_max <- iris %>% group_by(Species) %>% slice_max(Petal.Length, n = 1)

p + geom_text(data = iris_max, aes(label = Species), 
            color = "black", size = 3)


#- anotaciones con geom_XX_line()
p + geom_vline(xintercept = 6) 

p + geom_hline(yintercept = 5,
             size = 1.7,
             colour = "purple",
             linetype = "dashed") 

p + geom_abline(intercept = 0.7,
              slope = 0.4,
              size = 2,
              colour = "steelblue")


#- LIMITES de los ejes ---------------------------------------------------------


#- ESCALAS (!!) ----------------------------------------------------------------


#- STATS (!!) ------------------------------------------------------------------



#- POSITION adjustments --------------------------------------------------------

#- slide nº 29 ----

p <- ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() 

p  + geom_point(position = "jitter", color = "pink")



#- slide nº 30 ----

p <- ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) 
p + geom_bar() 
p + geom_bar(position = "fill")
p + geom_bar(position = "dodge")
p + geom_bar(position = position_dodge2(preserve = "single"))



#- COMBINANDO gráficos ---------------------------------------------------------

#- slide nº 32 ----

library(patchwork)
p1 <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() + theme(legend.position = "none")
p2 <- ggplot(iris)+ aes(Species, Sepal.Length) + geom_boxplot()
p3 <- ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_density(position = "stack", alpha = 0.5)
p1 + p2 / p3


#- slide nº 33 ----

library(patchwork)
img_twitter <- magick::image_read('https://raw.githubusercontent.com/lgellis/MiscTutorial/master/Patchwork/twitter_post.png')
img <- magick::image_read("https://patchwork.data-imaginist.com/reference/figures/logo.png")
p_twitter <- ggplot() + ggpubr::background_image(img_twitter) + coord_fixed() 
p_img <- ggplot() + ggpubr::background_image(img) + coord_fixed()

p_twitter + ((p1 + plot_spacer()) / (p_img + p3))



#- slides_06C: tipos de gráficos -----------------------------------------------

#- slide nº 4 ----
#- histogramas

p <- ggplot(iris, aes(Sepal.Length)) +
  geom_histogram(bins = 60) + labs(title = "60 intervalos (o bins)")

p
 
p + geom_histogram(bins = 40) + labs(title = "40 intervalos") 

p + geom_histogram(binwidth = 0.5) + labs(title = "En lugar de elegir el nº de intervalos, \n se puede elegir la anchura del intervalo: \n binwidth =  0.5") 



p + geom_histogram(binwidth = 0.5,
                 color = "black",
                 fill = "tomato") + labs(title = "binwidth =  0.5, color = black, fill = tomato") 
  
  
p + geom_histogram(binwidth = 0.5,
                 aes(fill = Species),
                 color = "black") + labs(title = "binwidth =  0.5, color = black, aes(fill = Species)") +
    facet_grid(cols = vars(Species))


#- slide nº 5 ----
#- geom_density() y Joy Division plots

ggplot(iris, aes(Sepal.Length, fill = Species)) + 
  geom_density(position = "stack", alpha = 0.5) 



ggplot(iris, aes(x = Sepal.Length, y = Species)) + 
  ggridges::geom_density_ridges(aes(fill = Species), alpha = 0.5)


#- graficos de caja
p <- ggplot(iris, aes(x = Species,  y = Sepal.Length)) +
  geom_boxplot() 
p

p1 <- p + geom_boxplot(aes(fill = Species),
               outlier.colour = "purple") 
p1

p2 <- p1 + geom_jitter(width = 0.15, alpha = 1/4, color = "tomato") 
p2 

p2 + stat_summary(fun = "mean", geom = "point", color = "purple", size = 2.5) +
  geom_violin(aes(fill = Species), alpha = 0.6) +
  coord_flip()


#- gráficos de barra
p1 <- ggplot(mpg, aes(class)) + geom_bar() 
p1

p1 + geom_bar(fill = "steelblue") +
  coord_flip()


#- slide nº 6 ----
#- gráficos de barra (posiciones)

p <- ggplot(mtcars, aes(factor(cyl), fill = factor(vs)))
p + geom_bar() 
p + geom_bar(position = "fill")
p + geom_bar(position = "dodge")
p + geom_bar(position = position_dodge2(preserve = "single"))


#- INTERACTIVOS ----------------------------------------------------------------
#- html widgets: http://gallery.htmlwidgets.org/
#- ejemplos: https://r-graph-gallery.com/interactive-charts.html

#- slide nº 9 ----

library(plotly)

p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() + geom_smooth()
ggplotly(p)


p1 <- p + facet_grid(cols = vars(Species)) 
ggplotly(p1)
